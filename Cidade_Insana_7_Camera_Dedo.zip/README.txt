Cidade Insana 7 — controle de câmera pelo dedo

Agora existe uma área de toque no lado direito da tela:
- arraste o dedo para esquerda/direita para girar a câmera;
- arraste para cima/baixo para mudar o ângulo;
- o boneco acompanha a direção da câmera;
- as setas do lado esquerdo continuam movimentando o personagem.

Abra index.html com internet disponível.
